const openBtn = document.getElementById("openBtn");
const toast = document.getElementById("toast");

openBtn.addEventListener("click", () => {
  openBtn.style.transform = "scale(.92) rotate(2deg)";
  setTimeout(() => {
    document.getElementById("home").nextElementSibling.scrollIntoView({behavior:"smooth"});
    toast.classList.add("show");
    setTimeout(()=>toast.classList.remove("show"), 2200);
  }, 250);
});

// Photo previews
document.querySelectorAll(".photo-input").forEach(input => {
  input.addEventListener("change", e => {
    const file = e.target.files[0];
    if (!file) return;
    const box = e.target.parentElement.querySelector(".photo");
    const url = URL.createObjectURL(file);
    box.innerHTML = `<img src="${url}" alt="Memory photo">`;
  });
});

// Clickable love notes
document.querySelectorAll(".note-card").forEach(card => {
  card.addEventListener("click", () => {
    card.classList.toggle("revealed");
    toast.textContent = card.classList.contains("revealed")
      ? "♡ You found one of my little reasons ♡"
      : "♡";
    toast.classList.add("show");
    setTimeout(()=>toast.classList.remove("show"), 1600);
  });
});

// Local audio preview
const audioInput = document.getElementById("audioInput");
const audioPlayer = document.getElementById("audioPlayer");
audioInput.addEventListener("change", e => {
  const file = e.target.files[0];
  if (!file) return;
  audioPlayer.src = URL.createObjectURL(file);
  audioPlayer.play().catch(()=>{});
});

// Scroll reveal
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) entry.target.classList.add("visible");
  });
}, {threshold:.12});
document.querySelectorAll(".reveal").forEach(el => observer.observe(el));

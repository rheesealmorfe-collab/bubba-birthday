# Bubba Birthday Website ♡

Files:
- index.html — the website
- style.css — design and animations
- script.js — interactions

How to use:
1. Open index.html in Chrome to preview it.
2. Click each "Add photo" box and select your six photos.
3. Edit the birthday letter directly in index.html if you want your own message.
4. For the song, use the audio picker to preview an audio file you have the right to use.
5. For a public website, upload these files to a free static hosting service such as GitHub Pages or Netlify.

Important:
- The photo picker is for previewing photos in your browser. For a permanent online version, put your six image files in an assets folder and change the photo boxes to use those files.
- The site does not include the copyrighted audio for "Palayo sa Mundo."
